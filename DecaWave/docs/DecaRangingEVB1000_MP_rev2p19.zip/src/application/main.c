// -------------------------------------------------------------------------------------------------------------------
//
//  File: main.c -
//
//  Copyright 2011 (c) DecaWave Ltd, Dublin, Ireland.
//
//  All rights reserved.
//
//  Author: Zoran Skrba, March 2012
//
// -------------------------------------------------------------------------------------------------------------------

/* Includes */
#include "compiler.h"
#include "port.h"

#include "instance.h"

#include "deca_types.h"

#include "deca_spi.h"

extern void usb_run(void);
extern int usb_init(void);

#define SOFTWARE_VER_STRING    "Version 2.19    " //


int instance_anchaddr = 0;
int dr_mode = 0;
//if instance_mode = TAG_TDOA then the device cannot be selected as anchor
int instance_mode = ANCHOR;
//int instance_mode = TAG;
//int instance_mode = TAG_TDOA;
//int instance_mode = LISTENER;
int paused = 0;

double antennaDelay  ;                          // This is system effect on RTD subtracted from local calculation.


char reset_request;

typedef struct
{
    uint8 channel ;
    uint8 prf ;
    uint8 datarate ;
    uint8 preambleCode ;
    uint8 preambleLength ;
    uint8 pacSize ;
    uint8 nsSFD ;
} chConfig_t ;


//Configuration for DecaRanging Modes (8 default use cases selectable by the switch S1 on EVK)
chConfig_t chConfig[8] ={
					//mode 1 - S1: 7 off, 6 off, 5 off
					{
						2,              // channel
						DWT_PRF_16M,    // prf
						DWT_BR_110K,    // datarate
                        3,             // preambleCode
                        DWT_PLEN_1024,	// preambleLength
                        DWT_PAC32,		// pacSize
                        1		// non-standard SFD
                    },
                    //mode 2
					{
						2,              // channel
						DWT_PRF_16M,    // prf
						DWT_BR_6M8,    // datarate
                        3,             // preambleCode
                        DWT_PLEN_128,	// preambleLength
                        DWT_PAC8,		// pacSize
                        0		// non-standard SFD
                    },
                    //mode 3
					{
						2,              // channel
						DWT_PRF_64M,    // prf
						DWT_BR_110K,    // datarate
                        9,             // preambleCode
                        DWT_PLEN_1024,	// preambleLength
                        DWT_PAC32,		// pacSize
                        1		// non-standard SFD
                    },
                    //mode 4
					{
						2,              // channel
						DWT_PRF_64M,    // prf
						DWT_BR_6M8,    // datarate
                        9,             // preambleCode
                        DWT_PLEN_128,	// preambleLength
                        DWT_PAC8,		// pacSize
                        0		// non-standard SFD
                    },
                    //mode 5
					{
						5,              // channel
						DWT_PRF_16M,    // prf
						DWT_BR_110K,    // datarate
						3,             // preambleCode
						DWT_PLEN_1024,	// preambleLength
						DWT_PAC32,		// pacSize
						1		// non-standard SFD
					},
					//mode 6
					{
						5,              // channel
						DWT_PRF_16M,    // prf
						DWT_BR_6M8,    // datarate
						3,             // preambleCode
						DWT_PLEN_128,	// preambleLength
						DWT_PAC8,		// pacSize
						0		// non-standard SFD
					},
					//mode 7
					{
						5,              // channel
						DWT_PRF_64M,    // prf
						DWT_BR_110K,    // datarate
						9,             // preambleCode
						DWT_PLEN_1024,	// preambleLength
						DWT_PAC32,		// pacSize
						1		// non-standard SFD
					},
					//mode 8
					{
						5,              // channel
						DWT_PRF_64M,    // prf
						DWT_BR_6M8,    // datarate
						9,             // preambleCode
						DWT_PLEN_128,	// preambleLength
						DWT_PAC8,		// pacSize
						0		// non-standard SFD
					}
};


#if (DR_DISCOVERY == 0)
//Tag address list
uint64 tagAddressList[3] =
{
	 0xDECA010000001001,         // First tag
     0xDECA010000000002,         // Second tag
     0xDECA010000000003          // Third tag
} ;

//Anchor address list
uint64 anchorAddressList[ANCHOR_LIST_SIZE] =
{
     0xDECA020000000001 ,       // First anchor
     0xDECA020000000002 ,       // Second anchor
     0xDECA020000000003 ,       // Third anchor
     0xDECA020000000004         // Fourth anchor
} ;

//ToF Report Forwarding Address
uint64 forwardingAddress[1] =
{
	 0xDECA030000000001
} ;


// ======================================================
//
//  Configure instance tag/anchor/etc... addresses
//
void addressconfigure(void)
{
    instanceAddressConfig_t ipc ;

    ipc.forwardToFRAddress = forwardingAddress[0];
    ipc.anchorAddress = anchorAddressList[instance_anchaddr];
    ipc.anchorAddressList = anchorAddressList;
    ipc.anchorListSize = ANCHOR_LIST_SIZE ;
    ipc.anchorPollMask = 0x1; //0x7;              // anchor poll mask

    ipc.sendReport = 1 ;  //1 => anchor sends TOF report to tag
    //ipc.sendReport = 2 ;  //2 => anchor sends TOF report to listener

    instancesetaddresses(&ipc);
}
#endif

uint32 inittestapplication(void);

// Restart and re-configure
void restartinstance(void)
{
    instance_close() ;                          //shut down instance, PHY, SPI close, etc.

    spi_peripheral_init();                      //re initialise SPI...

    inittestapplication() ;                     //re-initialise instance/device
} // end restartinstance()


void button_callback(void)
{

}

int decarangingmode(void)
{
	int mode = 0;

	if(is_switch_on(TA_SW1_5))
	{
		mode = 1;
	}

	if(is_switch_on(TA_SW1_6))
	{
		mode = mode + 2;
	}

	if(is_switch_on(TA_SW1_7))
	{
		mode = mode + 4;
	}

	return mode;
}

uint32 inittestapplication()
{
    uint32 devID ;
    instanceConfig_t instConfig;
    int i , result;

    SPI_ConfigFastRate(SPI_BaudRatePrescaler_16);  //max SPI before PLLs configured is ~4M

    i = 10;

	//this is called here to wake up the device (i.e. if it was in sleep mode before the restart)
    devID = instancereaddeviceid() ;
    if(DWT_DEVICE_ID != devID) //if the read of devide ID fails, the DW1000 could be asleep
    {
    	port_SPIx_clear_chip_select();	//CS low
    	Sleep(1);	//200 us to wake up then waits 5ms for DW1000 XTAL to stabilise
    	port_SPIx_set_chip_select();  //CS high
    	Sleep(7);
    	devID = instancereaddeviceid() ;
        // SPI not working or Unsupported Device ID
    	if(DWT_DEVICE_ID != devID)
    		return(-1) ;
    	//clear the sleep bit - so that after the hard reset below the DW does not go into sleep
    	dwt_softreset();
    }

	//reset the DW1000 by driving the RSTn line low
	reset_DW1000();

    result = instance_init() ;
    if (0 > result) return(-1) ; // Some failure has occurred

    SPI_ConfigFastRate(SPI_BaudRatePrescaler_4); //increase SPI to max
    devID = instancereaddeviceid() ;

    if (DWT_DEVICE_ID != devID)   // Means it is NOT MP device
    {
        // SPI not working or Unsupported Device ID
		return(-1) ;
    }

	if(port_IS_TAG_pressed() == 0)
	{
		instance_mode = TAG;
		led_on(LED_PC7);
	}
	else
	{
		instance_mode = ANCHOR;
		led_on(LED_PC6);
	}

    instancesetrole(instance_mode) ;     // Set this instance role

    dr_mode = decarangingmode();

    instConfig.channelNumber = chConfig[dr_mode].channel ;
    instConfig.preambleCode = chConfig[dr_mode].preambleCode ;
    instConfig.pulseRepFreq = chConfig[dr_mode].prf ;
    instConfig.pacSize = chConfig[dr_mode].pacSize ;
    instConfig.nsSFD = chConfig[dr_mode].nsSFD ;

    instConfig.dataRate = chConfig[dr_mode].datarate ;
    instConfig.preambleLen = chConfig[dr_mode].preambleLength ;

    instance_config(&instConfig) ;                  // Set operating channel etc

#if (DR_DISCOVERY == 0)
    addressconfigure() ;                            // set up initial payload configuration
#endif
    instancesettagsleepdelay(400); //set the Tag sleep time

    if(is_button_low() == S1_SWITCH_ON)
    	instancesetreplydelay(FIXED_REPLY_DELAY);
    else
    	instancesetreplydelay(FIXED_LONG_REPLY_DELAY);

    //use this to set the long blink response delay (e.g. when ranging with a PC anchor that wants to use the long response times)
    if(is_switch_on(TA_SW1_8) == S1_SWITCH_ON)
    	instancesetblinkreplydelay(FIXED_LONG_BLINK_RESPONSE_DELAY);

    return devID;
}
/**
**===========================================================================
**
**  Abstract: main program
**
**===========================================================================
*/

void process_deca_irq(void)
{
    do{

    	instance_process_irq(0);

    }while(port_CheckIRQ() == 1); //while IRS line active (ARM can only do edge sensitive interrupts)

}

void initLCD(void)
{
	uint8 initseq[9] = { 0x39, 0x14, 0x55, 0x6D, 0x78, 0x38 /*0x3C*/, 0x0C, 0x01, 0x06 };
	uint8 command = 0x0;
	int j = 100000;

	writetoLCD( 9, 0,  initseq); //init seq
	while(j--);

	command = 0x2 ;  //return cursor home
	writetoLCD( 1, 0,  &command);
	command = 0x1 ;  //clear screen
	writetoLCD( 1, 0,  &command);
}


void test_application_run(void)
{
	uint8 dataseq[40];

	while(1)
	{
		int j = 1000000;
		uint8 command;

		memset(dataseq, 0, 40);

		while(j--);
		//command = 0x1 ;  //clear screen
		//writetoLCD( 1, 0,  &command);
		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);

		//memcpy(dataseq, (const uint8 *) "DECAWAVE   ", 12);
		//writetoLCD( 12, 1, dataseq); //send some data

		j = 1000000;

		while(j--);

		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);
		//command = 0x1 ;  //clear screen
		//writetoLCD( 1, 0,  &command);

		memset(dataseq, 0, 40);

		if(is_switch_on(TA_SW1_3))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 3 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		if(is_switch_on(TA_SW1_4))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 4 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		if(is_switch_on(TA_SW1_5))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 5 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		if(is_switch_on(TA_SW1_6))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 6 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		if(is_switch_on(TA_SW1_7))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 7 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		if(is_switch_on(TA_SW1_8))
		{
			memcpy(dataseq, (const uint8 *) "SWITCH 8 ON ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(dataseq, (const uint8 *) "                ", 16);
			writetoLCD( 16, 1, dataseq); //send some data
		}
	}
}



int main(void)
{
 	int i = 0;
	uint32 status = 0;
	uint32 states = 0;
	uint8 dataseq[40];

	led_off(LED_ALL); //turn off all the LEDs

    peripherals_init();

    spi_peripheral_init();

	initLCD();

	memset(dataseq, 40, 0);
	memcpy(dataseq, (const uint8 *) "DECAWAVE        ", 16);
	writetoLCD( 40, 1, dataseq); //send some data
	memcpy(dataseq, (const uint8 *) SOFTWARE_VER_STRING, 16); // Also set at line #26 (Should make this from single value !!!)
	writetoLCD( 16, 1, dataseq); //send some data

	Sleep(2000);

    port_DisableIRQ(); //disable ScenSor IRQ until we configure the device

    //test LCD - temp (will be replaced by USB SPI operation)
#if 1
    if((is_button_low() == S1_SWITCH_ON) && (is_switch_on(TA_SW1_8) == S1_SWITCH_ON)) //using BOOT1 switch for test
    {
		test_application_run(); //does not return....
    }
    else
#endif
    if(is_switch_on(TA_SW1_3) == S1_SWITCH_OFF)
    {
		int j = 1000000;
		uint8 command;

		memset(dataseq, 0, 40);

		while(j--);
		//command = 0x1 ;  //clear screen
		//writetoLCD( 1, 0,  &command);
		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);

		memcpy(dataseq, (const uint8 *) "DECAWAVE   ", 12);
		writetoLCD( 40, 1, dataseq); //send some data
#ifdef USB_SUPPORT //this is set in the port.h file
		memcpy(dataseq, (const uint8 *) "USB to SPI ", 12);
#else
#endif
		writetoLCD( 16, 1, dataseq); //send some data

		j = 1000000;

		while(j--);

		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);
#ifdef USB_SUPPORT //this is set in the port.h file
    	// enable the USB functionality
		usb_init();

		// Do nothing in foreground -- allow USB application to run, I guess on the basis of USB interrupts?
		while (1)		// loop forever
		{
			usb_run();
		}
#endif
		return 1;
    }
    else //run DecaRanging application
    {
		uint8 dataseq[40];
		uint8 command = 0x0;

		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);
		memset(dataseq, ' ', 40);
		memcpy(dataseq, (const uint8 *) "DECAWAVE  RANGE", 15);
		writetoLCD( 15, 1, dataseq); //send some data

		led_off(LED_ALL);

	    if(inittestapplication() == (uint32)-1)
	    {
	        led_on(LED_ALL); //to display error....
	        dataseq[0] = 0x2 ;  //return cursor home
			writetoLCD( 1, 0,  &dataseq[0]);
			memset(dataseq, ' ', 40);
	    	memcpy(dataseq, (const uint8 *) "ERROR   ", 12);
	    	writetoLCD( 40, 1, dataseq); //send some data
	    	memcpy(dataseq, (const uint8 *) "  INIT FAIL ", 12);
	    	writetoLCD( 40, 1, dataseq); //send some data
	        return 0; //error
	    }

		//sleep for 5 seconds displaying "Decawave"
		i=25;
		while(i--)
		{
			if (i & 1) led_off(LED_ALL);
			else	led_on(LED_ALL);

			Sleep(200);
		}
		i = 0;
		led_off(LED_ALL);
		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);

		memset(dataseq, ' ', 40);

		if(port_IS_TAG_pressed() == 0)
		{
			instance_mode = TAG;
			led_on(LED_PC7);
		}
		else
		{
			instance_mode = ANCHOR;
			led_on(LED_PC6);
		}

		if(instance_mode == TAG)
		{
			memcpy(&dataseq[2], (const uint8 *) "  AWAITING  ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(&dataseq[2], (const uint8 *) "  RESPONSE  ", 12);
			writetoLCD( 16, 1, dataseq); //send some data
		}
		else
		{
			memcpy(&dataseq[2], (const uint8 *) "  AWAITING  ", 12);
			writetoLCD( 40, 1, dataseq); //send some data
			memcpy(&dataseq[2], (const uint8 *) "    POLL    ", 12);
			writetoLCD( 16, 1, dataseq); //send some data
		}

		command = 0x2 ;  //return cursor home
		writetoLCD( 1, 0,  &command);
    }

    port_EnableIRQ(); //enable ScenSor IRQ before starting

    // main loop
    while(1)
    {
    	//DEBUG
#if 1
    	if(i==1)
		{
			states = 0;
			uint32 addr = 0;
			uint32 offset = 0;
			uint32 value = 0;

			status = dwt_read32bitoffsetreg(0xF, 0x0);
			states = dwt_read32bitoffsetreg(0x19, 0x0);

			states = dwt_read32bitoffsetreg(0x19, 0x1);

			dwt_write32bitoffsetreg(addr, offset, value);
		}
#endif

		//system_services();
		instance_run();

		if(instancenewrange())
		{
			//send the new range information to Location Engine
			double range_result = 0;
			double avg_result = 0;
			uint8 dataseq[40];
			range_result = instance_get_idist();
			avg_result = instance_get_adist();
			//set_rangeresult(range_result);
			dataseq[0] = 0x2 ;  //return cursor home
			writetoLCD( 1, 0,  dataseq);

			memset(dataseq, ' ', 40);
			sprintf((char*)&dataseq[1], "LAST: %4.2f m", range_result);
			writetoLCD( 40, 1, dataseq); //send some data
			sprintf((char*)&dataseq[1], "AVG8: %4.2f m", avg_result);
			writetoLCD( 16, 1, dataseq); //send some data
		}
    }


    return 0;
}



